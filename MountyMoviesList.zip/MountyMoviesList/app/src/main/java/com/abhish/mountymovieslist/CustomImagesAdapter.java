package com.abhish.mountymovieslist;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class CustomImagesAdapter extends FirebaseRecyclerAdapter<CustomImages, CustomImagesAdapter.CustomImagesViewholder> {

    private View mainContext;
    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public CustomImagesAdapter(@NonNull FirebaseRecyclerOptions<CustomImages> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final CustomImagesViewholder holder, int position, @NonNull final CustomImages model) {

        //Picasso.get().load(model.getPoster_path()).placeholder(R.drawable.progress_animation).into(holder.imageView);
        holder.titleView.setText("Title : " + model.getTitle());
        holder.languageView.setText("Language : "+ model.getLangauage());
        holder.releaseView.setText("Release Date : "+ model.getRelease_date());
        holder.votesView.setText("Votes : "+ model.getVote_count());
        holder.load_anim.setVisibility(View.VISIBLE);
        Glide.with(mainContext).load(model.getPoster_path()).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                holder.load_anim.setVisibility(View.GONE);
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                holder.load_anim.setVisibility(View.GONE);
                return false;
            }
        }).into(holder.imageView);
    }

    @NonNull
    @Override
    public CustomImagesViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_image, parent, false);

        return new CustomImagesViewholder(view);
    }

    class CustomImagesViewholder extends RecyclerView.ViewHolder{

        ImageView imageView;
        ImageView load_anim;

        TextView titleView;
        TextView releaseView;
        TextView languageView;
        TextView votesView;

        public CustomImagesViewholder(@NonNull View itemView) {
            super(itemView);
            mainContext=itemView;

            languageView=itemView.findViewById(R.id.language);
            votesView=itemView.findViewById(R.id.votes);
            releaseView=itemView.findViewById(R.id.release_date);
            titleView=itemView.findViewById(R.id.title);
            imageView=itemView.findViewById(R.id.image_view);
            load_anim=itemView.findViewById(R.id.load_anim);
        }

        }
}