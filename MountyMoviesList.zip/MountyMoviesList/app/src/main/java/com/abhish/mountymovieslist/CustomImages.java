package com.abhish.mountymovieslist;

public class CustomImages {

    public String poster_path;
    public String release_date;
    public String title;
    public int vote_count;
    public String langauage;


    public String getLangauage() {
        return langauage;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public String getRelease_date() {
        return release_date;
    }

    public String getTitle() {
        return title;
    }

    public int getVote_count() {
        return vote_count;
    }

}
