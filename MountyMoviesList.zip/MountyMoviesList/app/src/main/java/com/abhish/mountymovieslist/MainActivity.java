package com.abhish.mountymovieslist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    RecyclerView topRecyclerView,upcomingRecyclerView;
    CustomImagesAdapter customImagesAdapter,customImagesAdapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        topRecyclerView=findViewById(R.id.recycler_list1);
        topRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<CustomImages> options =
                new FirebaseRecyclerOptions.Builder<CustomImages>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("CustomImages"), CustomImages.class)
                        .build();

        customImagesAdapter=new CustomImagesAdapter(options);
        topRecyclerView.setAdapter(customImagesAdapter);
        customImagesAdapter.startListening();

        upcomingRecyclerView=findViewById(R.id.recycler_list2);
        upcomingRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<CustomImages> options1 =
                new FirebaseRecyclerOptions.Builder<CustomImages>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("CustomImages1").child("CustomImages1"), CustomImages.class)
                        .build();

        customImagesAdapter1=new CustomImagesAdapter(options1);
        upcomingRecyclerView.setAdapter(customImagesAdapter1);
        customImagesAdapter1.startListening();


    }

    @Override
    protected void onStart() {
        super.onStart();
        customImagesAdapter.startListening();
        customImagesAdapter1.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        customImagesAdapter.stopListening();
        customImagesAdapter1.startListening();
    }
}
